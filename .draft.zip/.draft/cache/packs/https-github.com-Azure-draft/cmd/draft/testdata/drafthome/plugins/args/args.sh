#!/bin/bash
echo $*
