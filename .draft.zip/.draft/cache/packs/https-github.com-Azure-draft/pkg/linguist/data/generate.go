package data

//go:generate go run generate_classifier.go
//go:generate go-bindata -pkg data -o data.go classifier
