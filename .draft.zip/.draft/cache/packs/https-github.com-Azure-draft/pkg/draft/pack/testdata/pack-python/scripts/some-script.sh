# this is supposed to represent a file with something arbitrary in it
