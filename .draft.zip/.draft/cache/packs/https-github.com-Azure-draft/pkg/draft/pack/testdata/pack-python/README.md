pack readme
