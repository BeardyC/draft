# Code of Conduct

Please refer to Microsoft's [Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
